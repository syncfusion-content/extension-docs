---
layout: post
title: Register the Syncfusion License key | Extension | Syncfusion
description: register the syncfusion license key
platform: extension
control: Syncfusion Extensions
documentation: ug
---

# Register the Syncfusion License key

You need to register for the Syncfusion license for development purpose. The following steps guide you as to how to register for the Syncfusion license.

1. Download the [Syncfusion License](http://files2.syncfusion.com/Installs/Support/KB/RegisterProductkeyinBuildMachine.zip) Register tool and extract the file. 
2. Open the Command Prompt with administrator privileges.
3. Navigate to the root location of the extracted downloaded, Syncfusion license.
4. Run the following command to register the license key-Synckeynoui.exe “License key”.

   ![](Register-the-Syncfusion-License-key_images/Register-the-Syncfusion-License-key_img1.png)



