---
layout: post
title: ASPNET Extension | Extension | Syncfusion
description: ASPNET Extension
platform: extension
control: Syncfusion Extensions
documentation: ug
---

# ASP.NET Extension

## Overview

The Syncfusion ASP.NET Extensions provide quick access to create or configure the Syncfusion ASP.NET projects. The Syncfusion ASP.NET Extensions have the following features.


* Syncfusion Project Templates for ASP.NET Web Application and ASP.NET Web Site
* Syncfusion Project Conversion for ASP.NET Web Application
* Syncfusion Project Migration for ASP.NET Web Application

The Syncfusion ASP.NET Visual Studio Extensions are installed along with the following setups,

* Essential Studio for Enterprise Edition with the platform ASP.NET
* Essential Studio for ASP.NET


