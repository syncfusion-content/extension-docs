---
layout: post
title: Configure Syncfusion assemblies in Visual Studio project | Extension | Syncfusion
description: configure syncfusion assemblies in visual studio project
platform: extension
control: Syncfusion Extensions
documentation: ug
---

# Configure Syncfusion assemblies in Visual Studio project

The Syncfusion Reference Manager provides options to select from in the Context Menu of the project, right click on the project to see the Context Menu. The following screenshot shows this option in Visual Studio.   



![](Configure-Syncfusion-assemblies-in-Visual-Studio-project_images/Configure-Syncfusion-assemblies-in-Visual-Studio-project_img1.png)



