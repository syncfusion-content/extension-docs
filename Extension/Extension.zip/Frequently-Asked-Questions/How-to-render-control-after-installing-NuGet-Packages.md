---
layout: post
title: How-to-render-control-after-installing-NuGet-Packages
description: how to render control after installing nuget packages?
platform: extension
control: Syncfusion Extensions
documentation: ug
---

# How to render control after installing NuGet Packages?

Follow the steps provided in the given KB to render a control after installing Syncfusion NuGet Packages. KB link: [http://www.syncfusion.com/kb/4077](http://www.syncfusion.com/kb/4077)

