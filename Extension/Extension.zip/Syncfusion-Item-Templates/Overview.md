---
layout: post
title: Syncfusion Item Templates | Extension | Syncfusion
description: Syncfusion Item Templates
platform: extension
control: Syncfusion Extensions
documentation: ug
---

# Syncfusion Item Templates

Syncfusion provides Item Templates to add Syncfusion class files to the Project in a quick manner.

